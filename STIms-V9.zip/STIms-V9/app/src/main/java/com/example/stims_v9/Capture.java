package com.example.stims_v9;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Capture extends CaptureActivity {
}
