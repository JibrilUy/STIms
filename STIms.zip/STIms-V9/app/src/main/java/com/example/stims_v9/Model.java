package com.example.stims_v9;

public class Model {
    String Check_In , Check_Out, Name, Date;

    public String getCheck_in() {
        return Check_In;
    }
    public String getCheck_out() {
        return Check_Out;
    }
    public String getName() {
        return Name;
    }

    public String getDate() {
        return Date;
    }


}
