package com.example.stims_v9;

public class Model2 {
    String student_name;

    public String getStudent_name() {
        return student_name;
    }
}
